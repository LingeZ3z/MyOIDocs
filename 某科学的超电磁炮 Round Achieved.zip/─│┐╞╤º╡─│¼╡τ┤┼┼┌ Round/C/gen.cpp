#include "./../testlib.h"
#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+10;
char s[N];
char t[]={'a','b','c'};
signed main(signed argc,char *argv[]){
	registerGen(argc,argv,1);
	int n=opt<int>("n");
	int q=opt<int>("q");
	cout<<n<<' '<<q<<'\n';
	for(int i=1;i<=n;i++)s[i]=t[rnd.next(3)];
	cout<<(s+1)<<'\n';
	for(int i=1;i<=q;i++){
		int p=rnd.next(1ll,n);
		char c=t[rnd.next(3)];
		cout<<p<<' '<<c<<'\n';
	}
	return 0;
}
