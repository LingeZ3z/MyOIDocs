#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
const int N=100005;
int n,q,pa[N],pb[N],pc[N],a[N],s[N];
string str;
bool vis[N];
int main()
{
    freopen("Kamijo.in","r",stdin);
    freopen("Kamijo.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin>>n>>q>>str;
    for(int i=0;i<n;i++)pa[i]=pb[i]=pc[i]=-1;
    for(int i=0;i<n;i++)
    {
        if(str[i]=='a')s[i+1]=0;
        if(str[i]=='b')s[i+1]=1;
        if(str[i]=='c')s[i+1]=2;
    }
    for(int i=1;i<=q;i++)
    {
        int op;char c;
        cin>>op>>c;
        if(c=='a')s[op]=0;
        if(c=='b')s[op]=1;
        if(c=='c')s[op]=2;
        int ans=0x3f3f3f3f;
        for(int x=0;x<pow(3,n);x++)
        {
            for(int t=x,j=1;t,j<=n;t/=3,j++)a[j]=t%3;
            bool fa=false,fb=false,fc=false,ok=true;
            for(int j=n;j>=1;j--)
            {
                if(a[j]==0&&!fa)fa=true;
                if(fa&&a[j]==1)fb=true;
                if(fb&&a[j]==2)
                {
                    ok=false;
                    break;
                }
            }
            if(!ok)continue;
            int res=0;
            for(int j=n;j>=1;j--)
            {
                int k=n+1-j;
                res+=(s[k]!=a[j]);
            }
            ans=min(ans,res);
        }
        cout<<ans<<"\n";
    }
    return 0;
}