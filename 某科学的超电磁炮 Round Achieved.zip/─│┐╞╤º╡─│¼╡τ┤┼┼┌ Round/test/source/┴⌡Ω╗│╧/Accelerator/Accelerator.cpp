#include<iostream>
#include<cstdio>
#include<cmath>
#include<unordered_map>
#define ll long long
using namespace std;
const int T=1000005;
ll n,ans;
unordered_map<ll,bool> m;
inline ll chk(ll x)
{
    ll t=sqrtl(x);
    if(t*t==x)return t;
    return 0;
}
int main()
{
    freopen("Accelerator.in","r",stdin);
    freopen("Accelerator.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin>>n;
    ll tmp=3,t,sq=sqrtl(n);
    for(t=1;t*t*t<=n;t++); t--;
    ans+=sq-t;
    for(register ll a=t;a>=2;a--)
    {
        while(powl(a,tmp+1)<=n)tmp++;
        for(register ll b=2;b<=tmp;b++)
        {
            ll x=powl(a,b);
            if(m[x]==false&&chk(x)<=t){ans++;}
            m[x]=true;
        }
    }
    ans++;
    cout<<ans<<"\n";
    return 0;
}