#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("Misaka.in","r",stdin);
    freopen("Misaka.out","w",stdout);
    return 0;
}