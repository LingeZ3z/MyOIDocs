#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>
using namespace std;
const int N=100005;
int n,m,q,a[N];
queue<int> que;
vector<pair<int,int> > G[N];
int d[N],dd[N];bool inq[N];
inline void spfa(int s)
{
    for(int i=1;i<=n;i++)d[i]=0x3f3f3f3f,inq[i]=false;
    que.push(s);d[s]=0,inq[s]=true;
    while(!que.empty())
    {
        int u=que.front();que.pop();inq[u]=false;
        for(pair<int,int> node:G[u])
        {
            int v=node.second;
            int w=node.first;
            if(d[v]>d[u]+w)
            {
                d[v]=d[u]+w;
                if(!inq[v]){que.push(v);inq[v]=true;}
            }
        }
    }
}
int main()
{
    freopen("Kuriko.in","r",stdin);
    freopen("Kuriko.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin>>n>>m>>q;
    for(register int i=1;i<=n;i++)cin>>a[i];
    for(register int i=1;i<=m;i++)
    {
        int u,v;cin>>u>>v;
        G[u].push_back(make_pair(1,v));
        G[v].push_back(make_pair(1,u));
    }
    for(register int i=1;i<=n;i++)for(register int j=1;j<=n;j++)
        if(i!=j&&(a[i]&a[j])==a[j]&&a[i]!=-1&&a[j]!=-1)G[i].push_back(make_pair(0,j));
    for(register int i=1;i<=n;i++)sort(G[i].begin(),G[i].end());
    for(register int i=1;i<=q;i++)
    {
        int u,v;cin>>u>>v;
        spfa(u);
        cout<<d[v]<<"\n";
    }
    return 0;
}