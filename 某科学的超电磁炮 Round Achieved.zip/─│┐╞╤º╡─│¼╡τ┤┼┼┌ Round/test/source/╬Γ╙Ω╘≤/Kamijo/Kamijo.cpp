#include<cstdio>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#include<map>

#include<bitset>
#include<set>

#include<deque>
#include<cassert>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<vector>

#define fi first
#define se second
#define pb push_back
#define mk make_pair
#define DBG cerr << __LINE__ << ' ' << __FUNCTION__ << endl

#define DRE default_random_engine
#define UID uniform_int_distribution
#define y0 Y0
#define y1 Y1
#define endl '\n'

#define pi acos(-1)
#define eps (1e-8)
#define null nullptr

using namespace std;

const int INF = 0x3f3f3f3f;
typedef pair<int,int> PII;
typedef pair<int,PII> PIII;
const int N = 1e5 + 10;
const int M = 1e7 + 10;

int n, q, pos, len;
char c[N], ch;

struct seg{
	int sum[N<<2];
	void update(int p,int l,int r,int x,int k){
		if(l == r)	return (void)(sum[p] += k);
		int mid = l+r>>1;
		if(x<=mid)	update(p<<1, l, mid, x, k);
		else	update(p<<1|1, mid+1, r, x, k);
		sum[p] = sum[p<<1] + sum[p<<1|1];
	}
	int query(int p,int l,int r,int left,int right){
		if(left<=l && r<=right)	return sum[p];
		int mid = l+r>>1, res = 0;
		if(left<=mid)	res += query(p<<1, l, mid, left, right);
		if(right>mid)	res += query(p<<1|1, mid+1, r, left, right);
		return res;
	}
	int fir(int p,int l,int r){
		if(l == r)	return l;
		if(sum[p<<1])	return fir(p<<1, l, l+r>>1);
		else	return fir(p<<1|1, (l+r>>1)+1, r);
	}
	int lst(int p,int l,int r){
		if(l == r)	return l;
		if(sum[p<<1|1])	return lst(p<<1|1, (l+r>>1)+1, r);
		else	return lst(p<<1, l, l+r>>1);
	}
}sa, sc, s;
set<int> sb;

void add(int i,char c){
	if(c == 'a')	sa.update(1, 1, len, i, 1);
	else if(c == 'b')	sb.insert(i), s.update(1, 1, len, i, 1);
	else	sc.update(1, 1, len, i, 1);
}
void del(int i,char c){
	if(c == 'a')	sa.update(1, 1, len, i, -1);
	else if(c == 'b')	sb.erase(i), s.update(1, 1, len, i, -1);
	else	sc.update(1, 1, len, i, -1);
}

signed main(){
    freopen("Kamijo.in","r",stdin);
    freopen("Kamijo.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin>>n>>q>>(c+1);
	len = strlen(c+1);
	for(int i=1;i<=len;++i)	add(i, c[i]);
	while(q--){
		cin>>pos>>ch;
		del(pos, c[pos]), add(pos, ch); c[pos] = ch;
		if(!sa.sum[1] || !sc.sum[1] || sb.empty()){
			cout<<0<<endl;
			continue;
		}
		int l = sa.fir(1, 1, len), r = sc.lst(1, 1, len);
		int ll = *sb.lower_bound(l);
		set<int>::iterator it = sb.upper_bound(r); --it;
		int rr = *it;
//		cout<<l<<" "<<r<<" "<<ll<<" "<<rr<<endl;
//		cout<<sc.query(1, 1, len, ll, r)<<" "<<sa.query(1, 1, len, l, rr)<<" "<<s.query(1, 1, len, ll, rr)<<endl;
		cout<<min(sc.query(1, 1, len, ll, r), min(sa.query(1, 1, len, l, rr), s.query(1, 1, len, ll, rr)))<<endl;
	}
	return 0;
}

/*
8 27 32 125 128 225 243 343 1000
8 27 32 125 128 225 243 343 512 529 576 625 676 729 784 841 900 961 1000
*/
