#include<cstdio>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#include<map>

#include<bitset>
#include<set>

#include<deque>
#include<cassert>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<vector>

#define fi first
#define se second
#define pb push_back
#define mk make_pair
#define DBG cerr << __LINE__ << ' ' << __FUNCTION__ << endl

#define DRE default_random_engine
#define UID uniform_int_distribution
#define y0 Y0
#define y1 Y1
#define endl '\n'

#define pi acos(-1)
#define eps (1e-8)
#define null nullptr

using namespace std;

const int INF = 0x3f3f3f3f;
typedef pair<int,int> PII;
typedef pair<int,PII> PIII;
const int N = 3e5 + 10;
const int M = 1e7 + 10;

int n, m, q, a[N];
vector<int> val[N];
vector<int> g[N], v[N];

int dis[N];
bool vis[N];
deque<pair<int, bool> > Q;
int bfs(int s,int t){
	for(int i=1;i<=n;++i)   dis[i] = INF, vis[i] = false;
	Q.push_back(mk(s, 1)); Q.push_back(mk(s, 0));
	dis[s] = 0;
	while(Q.size()){
		int x = Q.front().fi;
		bool f = Q.front().se; Q.pop_front();
		if(f){
			for(int y:g[x]){
				if(dis[y] == INF){
					dis[y] = dis[x] + 1;
					Q.push_back(mk(y, 1));
					Q.push_front(mk(y, 0));
				}
			}
		}else{
			for(int y:v[x]){
				if(dis[y] == INF){
					dis[y] = dis[x];
					Q.push_back(mk(y, 1));
					Q.push_front(mk(y, 0));
				}
			}
		}
	}
	return dis[t];
}

signed main(){
    freopen("Kuriko.in","r",stdin);
    freopen("Kuriko.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;++i)   cin>>a[i], val[a[i]].pb(i);
	for(int i=1, x, y;i<=m;++i)   cin>>x>>y, g[x].pb(y), g[y].pb(x);
	for(int i=1;i<=n;++i){
		for(int s=a[i];s;s=(s-1)&a[i]){
			for(int j:val[s])
				if(i != j)  v[i].pb(j);
		}
		for(int j:val[0])
			if(i != j)  v[i].pb(j);
	}
	while(q--){
		int x, y; cin>>x>>y;
		cout<<bfs(x, y)<<endl;
	}
	return 0;
}

