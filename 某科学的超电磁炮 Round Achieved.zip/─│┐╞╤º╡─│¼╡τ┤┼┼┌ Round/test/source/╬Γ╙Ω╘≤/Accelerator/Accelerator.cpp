#include<cstdio>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#include<map>

#include<bitset>
#include<set>

#include<deque>
#include<cassert>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<vector>

#define fi first
#define se second
#define pb push_back
#define mk make_pair
#define DBG cerr << __LINE__ << ' ' << __FUNCTION__ << endl

#define DRE default_random_engine
#define UID uniform_int_distribution
#define y0 Y0
#define y1 Y1
#define endl '\n'

#define pi acos(-1)
#define eps (1e-8)
#define null nullptr

using namespace std;

#define int __int128
const int INF = 0x3f3f3f3f;
typedef pair<int,int> PII;
typedef pair<int,PII> PIII;
const int N = 1e5 + 10;
const int M = 1e6 + 10;

int n, p[M], cnt, ans, isp[M], mu[M];
bool flag[M];

void init(){
	mu[1] = -1;
	for(int i=2;i<=M-10;++i){
		if(!isp[i])   p[++cnt] = i;
		for(int j=1;j<=cnt&&i*p[j]<=M-10;++j){
			isp[i*p[j]] = 1;
			if(i%p[j] == 0) break;
		}
	}
}

void re(int &x){
	x=0;bool f=0;char ch=getchar();
	while(ch<48||ch>57){if(ch==45)f=1;ch=getchar();}
	while(ch>=48&&ch<=57){x=(x<<1)+(x<<3)+(ch^	48);ch=getchar();}
	if(f)x=-x;return ;
}
void print(int x){
    if(x<0) print(-x);
    if(x>=10)    print(x/10);
    putchar(x%10+'0');
}


signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	 freopen("Accelerator.in","r",stdin);
	 freopen("Accelerator.out","w",stdout);
	re(n);
	// init();
	// print(pow(n,0.5)+pow(n,0.33)+pow(n,0.2)-pow(n,0.167)-pow(n,0.1)-pow(n,0.067)+pow(n,0.033)); puts("");
	ans = sqrtl(n);
	// print(ans), puts("");
	int nn = powl(n, 1.0/3)+0.5;
	// print(nn), puts("");
	// print(nn), puts("");
	// int res = 0;
	// for(int i=1;i<=25;++i)	res += pow(n, 1.0/p[i]);
	// print(res), puts("");
	int snn = sqrtl(nn);
	for(int i=1;i<=snn;++i)	flag[i*i] = true;
	for(int i=2;i<=nn;++i){
		int base = i*i*i;
		if(base > n || flag[i])	continue;
		for(int j=3;base<=n;base=base*i,++j){
			ans += j&1;
			// if(!(j&1) && !isp[j])	print(base), puts("");
			// print(j), puts("");
			if(base<=nn)	flag[base] = true;
			// if(!isp[j])	 print(base), putchar(' ');
		}
	}
	// puts("");
	print(ans), puts("");
	return 0;
}

/*
8 27 32 125 128 225 243 343 1000
8 27 32 125 128 225 243 343 512 529 576 625 676 729 784 841 900 961 1000
*/
