#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<ctime>
#include<iomanip>
#include<iostream>
#include<list>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<string>
#include<vector>
#define ll long long
#define DBG(x) cout << #x << "=" << x << endl
#define inf 0x3f3f3f3f
#define mod 998244353
#define N 200005
#define eps 1e-8
using namespace std;
template <typename T>
void read(T& x) {
    x = 0;
    ll t = 1;
    char ch;
    ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') {
            t = -1;
        }
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') {
        x = x * 10 + (ch - '0');
        ch = getchar();
    }
    x *= t;
}
template <typename T, typename... Args>
void read(T& first, Args&... args) {
    read(first);
    read(args...);
}
template <typename T>
void write(T y) {
    T x = y;
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    if (x > 9) {
        write(x / 10);
    }
    putchar(x % 10 + '0');
}
template <typename T, typename... Ts>
void write(T arg, Ts... args) {
    write(arg);
    if (sizeof...(args) != 0) {
        putchar(' ');
        write(args...);
    }
}
int n,m,q,a[N],x,y,head[N],ver[N],Next[N],w[N],tot=-1,dis[N],vis[N];
void add(int x,int y,int z){
	ver[++tot]=y;
	Next[tot]=head[x];
	w[tot]=z;
	head[x]=tot;
}
void SPFA(int x){
	memset(dis,inf,sizeof dis);
	memset(vis,0,sizeof vis);
	dis[x]=0;
	queue<int> q;
	q.push(x);
	vis[x]=1;
	while(!q.empty()){
		int u=q.front();
		q.pop();
		vis[u]=0;
		for(int i=head[u];i!=-1;i=Next[i]){
			int v=ver[i];
			if(dis[v]>dis[u]+w[i]){
				dis[v]=dis[u]+w[i];
				if(!vis[v]){
					vis[x]=1;
					q.push(v);
				}
			}
		}
	}
}
int main(){
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
	memset(head,-1,sizeof head);
	read(n,m,q);
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	for(int i=1;i<=m;i++){
		read(x,y);
		add(x,y,1);
		add(y,x,1);
	}
	for(int i=1;i<=n-1;i++){
		for(int j=i+1;j<=n;j++){
			if(a[i]==-1||a[j]==-1){
				continue;
			}
			if((a[i]&a[j])==a[j]){
				add(i,j,0);
			}
			if((a[j]&a[i])==a[i]){
				add(j,i,0);
			}
		}
	}
	while(q--){
		read(x,y);
		SPFA(x);
		write(dis[y]);
//		for(int i=1;i<=n;i++){
//			cout<<dis[i]<<" ";
//		}
		putchar('\n');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

