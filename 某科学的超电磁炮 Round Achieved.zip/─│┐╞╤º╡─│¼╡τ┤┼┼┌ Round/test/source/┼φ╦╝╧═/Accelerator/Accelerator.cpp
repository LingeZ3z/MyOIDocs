#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<ctime>
#include<iomanip>
#include<iostream>
#include<list>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<string>
#include<vector>
#define ll long long
#define DBG(x) cout << #x << "=" << x << endl
#define inf 0x3f3f3f3f
#define mod 998244353
#define N 100005
#define eps 1e-8
using namespace std;
template <typename T>
void read(T& x) {
    x = 0;
    ll t = 1;
    char ch;
    ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') {
            t = -1;
        }
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') {
        x = x * 10 + (ch - '0');
        ch = getchar();
    }
    x *= t;
}
template <typename T, typename... Args>
void read(T& first, Args&... args) {
    read(first);
    read(args...);
}
template <typename T>
void write(T y) {
    T x = y;
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    if (x > 9) {
        write(x / 10);
    }
    putchar(x % 10 + '0');
}
template <typename T, typename... Ts>
void write(T arg, Ts... args) {
    write(arg);
    if (sizeof...(args) != 0) {
        putchar(' ');
        write(args...);
    }
}
ll n,prime[80],isprime[80],num[80];
int tot;
ll change(ll x,ll y){
	ll sum=floorl(powl(1.0*x,1.0/(1.0*y))+eps);
	while(powl(sum+1,y)<=x){
		sum++;
	}
	while(powl(sum,y)>x){
		sum--;
	}
	return sum;
}
int main(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	read(n);
	for(int i=2;i<=62;i++){
		if(isprime[i]==0){
			tot++;
			prime[tot]=i;
		}
		for(int j=1;j<=tot&&i*prime[j]<=62;j++){
			isprime[i*prime[j]]=1;
			if(i%prime[j]==0){
				break;
			}
		}
	}
	ll ans=0;
	for(int i=1;i<=tot;i++){
		num[i]=change(n,prime[i]);
		ans=ans+(num[i]-1);
	}
	for(int i=1;i<=tot-1;i++){
		for(int j=i+1;j<=tot;j++){
			ll a=change(num[i],prime[j])-1;
			ll b=change(num[j],prime[i])-1;
			ans-=min(a,b);
		}
	}
	ans++;
	if(n>=1073741824){
		ans++;
	}
	if(n>=4398046511104){
		ans++;
	}
	if(n>=205891132094649){
		ans++;
	}
	write(ans);
	putchar('\n');
	fclose(stdin);
	fclose(stdout);
	return 0;
}

