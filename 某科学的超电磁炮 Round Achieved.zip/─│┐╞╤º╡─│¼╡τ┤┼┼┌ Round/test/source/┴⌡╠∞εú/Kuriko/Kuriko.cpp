#include <bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
int read(){
	char c=getchar();int h=0,tag=1;
	while(!isdigit(c)) tag=(c=='-'?-1:1),c=getchar();
	while(isdigit(c)) h=(h<<1)+(h<<3)+(c^48),c=getchar();
	return h*tag;
}
void fil(){
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
}
struct node{
	int v,w;
};
const int N=4e5+505;
int d[N],vis[N];vector<node>s[N];
void bfs(int st,int ed) {
	deque<int>q;
	memset(d,0x3f,sizeof d);
	memset(vis,0,sizeof vis);
	q.push_back(st);
	d[st]=0;
	while(!q.empty()) {
		int x=q.front();q.pop_front();
		if(vis[x]) continue;
		vis[x]=1;
		if(x==ed) return ;
		for(int i=0;i<s[x].size();i++) {
			int y=s[x][i].v,w=s[x][i].w;
			if(d[y]>d[x]+w) {
				d[y]=d[x]+w;
				if(w==0) q.push_front(y);
				else q.push_back(y);
			}
			
		}
	}
}
int a[N];
int n,m,q;
int main(){
	fil();
	n=read(),m=read(),q=read();
	int base=(1<<17);
	for(int i=1;i<=n;i++) {
		a[i]=read();
		if(a[i]==-1) continue;
		s[i+base].push_back(node{a[i],0});
		s[a[i]].push_back(node{i+base,0});
	}
	for(int i=1;i<base;i++) {
		for(int j=0;j<17;j++) {
			if((i&(1<<j))) {
				s[i].push_back(node{i-(1<<j),0});
			}
		}
	}
	for(int i=1;i<=m;i++) {
		int u=read(),v=read();
		s[u+base].push_back(node{v+base,1});
		s[v+base].push_back(node{u+base,1});
	}
	for(int i=1;i<=q;i++) {
		int u=read(),v=read();
		bfs(u+base,v+base);
		printf("%d\n",d[v+base]);
	}
	return 0;
}
