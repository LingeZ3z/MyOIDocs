#include <bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
int read(){
	char c=getchar();int h=0,tag=1;
	while(!isdigit(c)) tag=(c=='-'?-1:1),c=getchar();
	while(isdigit(c)) h=(h<<1)+(h<<3)+(c^48),c=getchar();
	return h*tag;
}
void fil(){
	freopen("Misaka.in","r",stdin);
	freopen("Misaka.out","w",stdout);
}
int die[22];
int dist(pii a,pii b) {
	return (a.fi-b.fi)*(a.fi-b.fi)+(a.se-b.se)*(a.se-b.se);
}
const int N=22;
pii a[N],b[N];
int c[N];
int main(){
	fil();
	int n=read(),m=read(),r=read();
	for(int i=1;i<=n;i++) {
		int x=read(),y=read();a[i]=pii(x,y);
	}
	for(int i=1;i<=m;i++) {
		int x=read(),y=read();b[i]=pii(x,y);
		c[i]=read();
	}
	int _cos=1e9,_ans=0;
	for(int i=0;i<(1<<m);i++) {
		int cos=0,ans=0;
		memset(die,0,sizeof die);
		for(int j=0;j<m;j++) {
			if((i&(1<<j))) {
				cos+=c[j+1];
				for(int k=1;k<=n;k++) {
					if(dist(a[k],b[j+1])<=r*r) die[k]=1;
				}
			}
		}
		for(int k=1;k<=n;k++) ans+=die[k];
		if(ans>_ans) {
			_cos=cos;
			_ans=ans;
		}	else if(ans==_ans) {
			_cos=min(_cos,cos);
		}	
	}
	cout<<_cos;
	return 0;
}


