#include <bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
int read(){
	char c=getchar();int h=0,tag=1;
	while(!isdigit(c)) tag=(c=='-'?-1:1),c=getchar();
	while(isdigit(c)) h=(h<<1)+(h<<3)+(c^48),c=getchar();
	return h*tag;
}
void fil(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
}
set<int>st;
int sqr(int p) {
	return sqrtl(p);
}
signed main(){
	fil();
	int n=read();
	int m=1e6;
	for(int i=2;i<=m;i++) {
		for(int j=i*i*i;j<=n;j=j*i) {
			if(j<0) break;
			st.insert(j);
			if(j>(n/i) ) break;			
		}
	}
	int ans=0;
	for(int x:st) {
		if(x==(sqr(x)*sqr(x)) ) {
			ans++;
		}
	}
	printf("%lld\n",(int)(st.size()+floor(sqrtl(n))-ans));
	return 0;
}
//268435456
//1000000000000000000
//1000000000
