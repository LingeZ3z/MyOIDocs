#include <bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
int read(){
	char c=getchar();int h=0,tag=1;
	while(!isdigit(c)) tag=(c=='-'?-1:1),c=getchar();
	while(isdigit(c)) h=(h<<1)+(h<<3)+(c^48),c=getchar();
	return h*tag;
}
void fil(){
	freopen("Kamijo.in","r",stdin);
	freopen("Kamijo.out","w",stdout);
}
const int N=1e5+500;
//struct seg{
	int tree[N*4];
	int a[N*4],b[N*4],c[N*4],ab[N*4],bc[N*4],abc[N*4];
	#define ls(p) (p<<1)
	#define rs(x) (x<<1|1)
	#define mid (l+r>>1)
	void push_up(int p) {
		a[p]=a[ls(p)]+a[rs(p)];
		b[p]=b[ls(p)]+b[rs(p)];
		c[p]=c[ls(p)]+c[rs(p)];
		ab[p]=min(min(a[p],b[p]),min(ab[ls(p)]+b[rs(p)],a[ls(p)]+ab[rs(p)]));//ab[ls(p)]+b[rs(p)],a[ls(p)]+ab[rs(p)]);
		bc[p]=min(min(b[p],c[p]),min(bc[ls(p)]+c[rs(p)],b[ls(p)]+bc[rs(p)]));//b[ls(p)]+c[rs(p)]);
		abc[p]=min(min(min(a[p],b[p]),c[p]),min(min(abc[ls(p)]+c[rs(p)],a[ls(p)]+abc[rs(p)] ),ab[ls(p)]+bc[rs(p)] ) );
	} 
	void update(int p,int l,int r,int x,char k) {
		if(l==r) {
			a[p]=b[p]=c[p]=0;
			if(k=='a') a[p]=1;
			if(k=='b') b[p]=1;
			if(k=='c') c[p]=1;
			return ;
		}
		if(x<=mid) update(ls(p),l,mid,x,k);
		else update(rs(p),mid+1,r,x,k);
		push_up(p);
	}
//};
char str[N+100];
int main(){
	fil();
	int n=read(),q=read();
	scanf("%s",str+1);
	for(int i=1;i<=n;i++) {
		update(1,1,n,i,str[i]);
	}
	for(int i=1;i<=q;i++) {
		int pos=read();
		char c=getchar();
		update(1,1,n,pos,c);
		printf("%d\n",abc[1]);
	} 
	return 0;
}
