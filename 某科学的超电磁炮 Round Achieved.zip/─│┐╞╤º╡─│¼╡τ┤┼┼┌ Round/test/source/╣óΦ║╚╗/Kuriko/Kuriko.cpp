#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
using namespace std;
typedef long long ll;

char buf[1<<20], *p1, *p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?0:*p1++)

inline ll read() {
	ll x=0, f=1; char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1; ch=getchar();}
	while (ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48), ch=getchar();
	return x*f;
}

#define N 100010
#define M 5000010
int n, m, qt, t1, t2;
int dis[N];
ll a[N], curpt;
bool vis[N], inq[N];
queue<int> q;

#define v e[i].to
#define w e[i].val
int head[N], tot;
struct edge {int to, nxt, val;} e[M<<1];
void add_edge(int x, int y, int z) {e[++tot]={y, head[x], z}, head[x]=tot;}

void spfa(int s) {
	while (!q.empty()) q.pop(); memset(inq, 0, sizeof(inq));
	memset(dis, 0x3f, sizeof(dis));
	dis[s]=0, q.push(s), inq[s]=1;
	while (!q.empty()) {
		int u=q.front(); q.pop(), inq[u]=0;
		// printf("%d\n", u);
		for (int i=head[u]; i; i=e[i].nxt) {
			if (dis[v]<=dis[u]+w) continue;
			dis[v]=dis[u]+w;
			if (!inq[v]) q.push(v);
		}
	}
}

// namespace trie {
// 	int ch[N*22][2], tot=0, rt;
// 	vector<int> val[N*22];
// 	int mknode() {ch[++tot][0]=ch[tot][1]=0; return tot;}
// 	void insert(int &x, int num, int dep) {
// 		if (!x) x=mknode();
// 		if (dep>20) {val[x].push_back(curpt); return;}
// 		insert(ch[x][num&1], num>>1, dep+1);
// 	}
// 	void dfs1(int x, int num, int dep) {
// 		if (dep>20) {
// 			for (auto i:val[x]) add_edge(curpt, i, 0);//, printf("%d %d\n", curpt, i);
// 			return;
// 		}
// 		if (ch[x][1]) dfs1(ch[x][1], num>>1, dep+1);
// 		dfs1(ch[x][num&1], num>>1, dep+1);
// 	}
// }

signed main() {
	freopen("Kuriko.in", "r", stdin);
	freopen("Kuriko.out", "w", stdout);
	n=read(), m=read(), qt=read();//, trie::rt=trie::mknode();
	for (int i=1; i<=n; ++i) {
		curpt=i, a[i]=read();
		// trie::insert(trie::rt, i, 0);
	}
	for (int i=1; i<=n; ++i) {
		for (int j=1; j<=n; ++j) if (a[i]!=-1&&a[j]!=-1&&a[i]&a[j]==a[i]) add_edge(j, i, 0);
		// curpt=i, trie::dfs1(trie::rt, i, 0);
		// trie::dfs2(trie::rt, i, 0);
	}
	for (int i=1; i<=m; ++i) {
		t1=read(), t2=read();
		add_edge(t1, t2, 1), add_edge(t2, t1, 1);
	}
	// puts("-");
	while (qt--) {
		t1=read(), t2=read();
		spfa(t1); printf("%d\n", dis[t2]);
	}
	return 0;
}

// 1. 为什么是与运算，且运算结果与终点相同？
// 2. 为什么会给出最终边数？
