#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
typedef long long ll;

// char buf[1<<20], *p1, *p2;
// #define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?0:*p1++)

inline ll read() {
	ll x=0, f=1; char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1; ch=getchar();}
	while (ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48), ch=getchar();
	return x*f;
}

#define INF 0x3f3f3f3f
#define N 100010
int n, ans;
int a[N], b[N];
int q, pos, c, cnt;

bool chk() {
	for (int i=1; i<=n; ++i) {
		for (int j=i; j<=n; ++j) {
			for (int k=j; k<=n; ++k) {
				if (b[i]==1&&b[j]==2&&b[k]==3) return 0;
			}
		}
	}
	return 1;
}

void dfs(int x, int dep, int dif) {
	if (dep>n) {
		if (chk()) ans=min(ans, dif);
		return;
	}
	b[dep]=x;
	dfs(1, dep+1, dif+(x==a[dep]));
	dfs(2, dep+1, dif+(x==a[dep]));
	dfs(3, dep+1, dif+(x==a[dep]));
}

signed main() {
	freopen("Kamijo.in", "r", stdin);
	freopen("Kamijo.out", "w", stdout);
	n=read(), q=read();
	while (a[1]<'a'||a[1]>'c') a[1]=getchar(); a[1]-='a'-1;
	for (int i=2; i<=n; ++i) a[i]=getchar()-'a'+1;
	while (q--) {
		ans=INF;
		pos=read(), c=getchar()-'a'+1;
		a[pos]=c;
		dfs(1, 1, 0), dfs(2, 1, 0), dfs(3, 1, 0);
		printf("%d\n", ans);
	}
	return 0;
}
