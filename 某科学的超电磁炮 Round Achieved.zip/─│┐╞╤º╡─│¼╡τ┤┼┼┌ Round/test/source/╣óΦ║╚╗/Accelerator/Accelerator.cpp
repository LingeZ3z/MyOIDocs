#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
typedef long long ll;

char buf[1<<20], *p1, *p2;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?0:*p1++)

inline ll read() {
	ll x=0, f=1; char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1; ch=getchar();}
	while (ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48), ch=getchar();
	return x*f;
}

ll qpow(ll a, ll b) {
	ll ans=1;
	while (b) {if (b&1) ans=ans*a; a=a*a, b>>=1;}
	return ans;
}

#define N 1000010
ll n, ed, ans;
bool vis[N][50];

signed main() {
	freopen("Accelerator.in", "r", stdin);
	freopen("Accelerator.out", "w", stdout);
	n=read();
	if (n==1) return puts("1"), 0;
	ed=log2(n);
	for (ll d=2; d<=n; ++d) {
		if (qpow(d, 2)>n) break;
		for (ll p=2; p<=ed; ++p) {
			if (qpow(d, p)>n) break;
			if (vis[d][p]) continue;
			// puts("-");
			for (ll x=d, k=1; ; ++k, x*=d) {
				if (x>=n) break;
				if (p%k) continue;
				// printf("%lld %lld\n", x, p/k);
				if (p/k<2) break;
				vis[x][p/k]=1;
			}
			printf("%lld %lld %lld\n", d, p, qpow(d,p));
			++ans;
		}
	}
	printf("%lld\n", ans+1);
	return 0;
}
