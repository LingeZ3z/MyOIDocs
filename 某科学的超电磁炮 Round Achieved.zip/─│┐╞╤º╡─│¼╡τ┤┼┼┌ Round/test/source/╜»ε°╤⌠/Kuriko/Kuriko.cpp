#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
const int N=2e5+10,M=5e6+10;
#define fin(a) freopen(#a".in","r",stdin)
#define fout(a) freopen(#a".out","w",stdout)
int n,m,q;
int a[N];
struct edge{
    int v,next,w;
}e[M];
int head[N],tot;
void add(int u,int v,int w){
    e[++tot]={v,head[u],w};
    head[u]=tot;
}
int dis[N],vis[N];
void bfs(int s,int t){
    queue<int> q;
    memset(dis,0x3f,sizeof(dis));
    memset(vis,0,sizeof(vis));
    q.push(s);
    vis[s]=1,dis[s]=0;
    while(q.size()){
        int u=q.front();
        q.pop();
        for(int i=head[u];i;i=e[i].next){
            int v=e[i].v;
            // cout<<u<<" "<<v<<endl;
            if(dis[u]+e[i].w<dis[v]){
                dis[v]=dis[u]+e[i].w;
                if(!vis[v]&&v!=t){
                    vis[v]=1;
                    q.push(v);
                }
            }
        }
    }
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    fin(Kuriko),fout(Kuriko);
    cin>>n>>m>>q;
    for(int i=1;i<=n;++i) cin>>a[i];
    for(int i=1,x,y;i<=m;++i){
        cin>>x>>y;
        add(x,y,1);
        add(y,x,1);
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            if(((a[i]&a[j])==a[j])&&i!=j) add(i,j,0);
    int x,y;
    while(q--){
        cin>>x>>y;
        bfs(x,y);
        cout<<dis[y]<<endl;
    }
    return 0;
}