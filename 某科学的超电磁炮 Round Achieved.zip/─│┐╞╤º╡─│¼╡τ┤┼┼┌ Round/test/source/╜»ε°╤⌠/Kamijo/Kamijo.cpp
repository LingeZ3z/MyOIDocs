#include<bits/stdc++.h>
#include<array>
using namespace std;
#define ll long long
#define endl '\n'
const int N=1e3+10;
const int INF=0x3f3f3f3f;
#define fin(a) freopen(#a".in","r",stdin)
#define fout(a) freopen(#a".out","w",stdout)
int n,q;
string s;
int solve(){
    vector<array<int,4> > dp(n+1,array<int,4>());
    dp[0][0]=0;
    for(int i=0;i<n;++i){
        int c=s[i]-'a'+1;
        dp[i+1]=dp[i];
        dp[i+1][c-1]++;
        dp[i+1][c]=min(dp[i+1][c],dp[i][c-1]);
    }
    return *min_element(dp[n].begin(),dp[n].begin()+3);
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    fin(Kamijo),fout(Kamijo);
    cin>>n>>q;
    cin>>s;
    char ch;
    int x;
    while(q--){
        cin>>x>>ch;
        s[--x]=ch;
        cout<<solve()<<endl;
    }
    return 0;
}
