#include<bits/stdc++.h>
using namespace std;
namespace IO{
    template<typename T> inline static void read(T &x){x=0;int f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x*10)+(ch^48);ch=getchar();}if(f==-1) x=-x;}
    template<typename T,typename ...Args> inline static void read(T& x,Args& ...args){read(x);read(args...);}
    template<typename T> inline static void write(char c,T x){T p=x;if(!p) putchar('0');if(p<0){putchar('-');p=-p;}int cnt[105],tot=0;while(p){cnt[++tot]=p%10;p/=10;}for(int i=tot;i>=1;i--){putchar(cnt[i]+'0');}putchar(c);}
    template<typename T,typename ...Args> inline static void write(const char c,T x,Args ...args){write(c,x);write(c,args...);}
}using namespace IO;
#define fin(a) freopen(#a".in","r",stdin)
#define fout(a) freopen(#a".out","w",stdout)
#define int __int128
int ksm(int a,int b,int lim){
    int res=1;
    while(b>0){
        if(b%2==1) res*=a;
        if(res>lim) return 0;
        if(b>1){
            a*=a;
            if(a>lim) return 0;
        }
        b/=2;
    }
    return 1;
}
int solve(int n){
    long long m=n;
    int ans=0,len=__lg(m);
    for(int i=2;i<=len;++i){
        int l=2,r=n,tmp=1;
        while(l<=r){
            int mid=(l+r)/2;
            if(ksm(mid,i,n)) l=mid+1,tmp=mid;
            else r=mid-1;
        }
        ans+=tmp-1;
        if(tmp>3) ans-=solve(tmp);
    }return ans;
}
int n;
signed main(){
    fin(Accelerator),fout(Accelerator);
    read(n);
    write('\n',solve(n)+1);
    return 0;
}