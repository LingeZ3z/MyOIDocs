#include<bits/stdc++.h>
using namespace std;
const int N=3e5+5;
int n,m,q;
struct node{
	int v,nxt,w;
}e[N<<1];
int tot,h[N];
int d[N];
int vis[N];
void add(int x,int y,int z){
	e[++tot].nxt=h[x];
	e[tot].v=y;
	e[tot].w=z;
	h[x]=tot;
}
void dfs(int u_fa,int u){
	int fl=1;
	vis[u]=1;
	for(int i=h[u];~i;i=e[i].nxt){
		int v=e[i].v,w=e[i].w;
	//	cout<<u<<" "<<v<<" "<<w<<endl;
		if(vis[v]) continue;
		if(w==0) {
			fl=0;
			d[v]=min(d[v],d[u]+w);
			dfs(u,v);
		} 
	}
	if(fl==1){
		for(int i=h[u];~i;i=e[i].nxt){
		int v=e[i].v,w=e[i].w;
	//	cout<<u<<" "<<v<<" "<<w<<endl;
		if(vis[v]) continue;
		if(w==1) {
			//	fl=0;
			d[v]=min(d[v],d[u]+w);
			dfs(u,v);
		} 
	}
	}
}
int a[N];
int main(){
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
	memset(h,-1,sizeof h);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		if(a[u]==-1||a[v]==-1) add(u,v,1);
		else if((a[u]&a[v])==a[v]) add(u,v,0);
		else add(u,v,1);
		add(v,u,1);
	//	cout<<u<<" "<<v<<" "<<1-(a[u]&a[v]==a[v])<<endl;;
	}
	//cout<<q<<endl;
	memset(d,0x3f,sizeof d);
	for(int i=1;i<=q;i++){
		int x,y;
		scanf("%d%d",&x,&y);
	//	cout<<x<<" "<<y<<endl;
		d[x]=0;
		dfs(0,x);
	//	cout<<"d[y]:"<<endl;
		printf("%d\n",d[y]);
		for(int j=1;j<=n;j++) vis[j]=0,d[j]=0x3f3f3f3f3f3f3f3f;
	}
	return 0;
}
