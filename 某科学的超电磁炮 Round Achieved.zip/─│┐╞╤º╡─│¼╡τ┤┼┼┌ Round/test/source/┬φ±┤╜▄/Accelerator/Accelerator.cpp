#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n;
ll m,m2;
ll ans; 
ll pr[109];
ll p3[109],p5[109];
ll ksm(ll x,ll y){
	ll ans=1;
	//cout<<y<<" "<<(!y)<<endl;
	while(y>=1){
	//	cout<<(y&1)<<endl;
		if(y%2==1){
			ans=ans*x;
		//	cout<<ans<<" "<<x<<" "<<y<<endl;
		}
		x=(x*x);
		y>>=1;
	//	cout<<y<<endl;
	}
	return ans;
}
int main(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	int pri=0,p3i=0,p5i=0;
	for(ll i=3;i<=100;i++){
		int fl=0;
		for(int j=2;j<i;j++) if(i%j==0) {
			fl=1;
			break;
		}
		if(!fl) pr[++pri]=i;
		//i//f(!fl) 
		//if(i<=50)
		p3[++p3i]=i*i*i;
		p5[++p5i]=i*i*i*i*i;
//		cout<<i*i*i<<" "<<i*i*i*i*i<<" "<<i*i*i*i*i*i*i<<" "<<i*i*i*i*i*i*i*i*i*i*i<<endl;
///		cout<<ksm(i,19)<<" "<<ksm(i,23);
	}
//	cout<<p3[p3i]<<" "<<p5[p5i]<<endl;
	scanf("%lld",&n);
	m=sqrtl(n);
	//cout<<m<<endl;
	ans+=m;
//	cout<<m<<endl;
	ll i=2,p=3,tot=1;
	while(ksm(i,p)<=n){
		int cnt=0;
		for(ll j=2;ksm(j,p)<=n;j++) 
		{
			ll k=ksm(j,p);
			if((ll)sqrtl(k)*(ll)sqrtl(k)==k) {
				//cout<<sqrt(k)<<" "<<k<<endl;
				continue;
			}
			if(p>3&&j==8) continue;
			if(p>3){
				int fll=0;
		//	cout<<p3[1]<<" "<<j<<endl;
				for(int k=1;p3[k]<=j&&k<=p3i;k++) {
			//		cout<<p3[k]<<" "<<j<<" "<<p3i<<endl;
					if(j==p3[k]) 
					{
						fll=1;
						continue;
					}
				}
				if(fll) continue;
			}	
			if(p>5){
				int fll=0;
				for(int k=1;p5[k]<=j&&k<=p5i;k++) {
					if(j==p5[k]){
						fll=1;
						continue;
					} 
				}
				if(fll) continue;
			}
			if(p>3&&(j==8||j==64||j==27||j==343||j==1331||j==2197||j==4913||j==6859||j==12167))
			{
				continue;
			} 
			if(p>3&&(j==125||j==216||j==512||j==729||j==1000)) continue;
			if(p>3&&(j==1728||j==2744||j==3375||j==4096||j==5832)) continue;
			if(p>5&&(j==32||j==243||j==16807||j==161051||j==2187)) continue;
			if(p>5&&(j==1024||j==3125||j==7776||j==59049)) continue;
			if(p>5&&(j==100000||j==59049||j==32768||j==248832)) continue;
			if(p>7&&(j==128||j==2187||j==78125||j==823543)) continue;
			if(p>7&&(j==16384||j==279936)) continue;
			if(p>11&&(j==2048||j==177147)) continue;
			if(p>13&&(j==8192)) continue;
			if(p>17&&(j==131072)) continue;
			if(p>19&&(j==524288)) continue;
			cnt++;
		}
	//	cout<<endl;
		ans+=cnt;
	//	cout<<p<<","<<cnt<<endl;
		p=pr[++tot];
	//	p++;
	//	if(p==15||p==21) p++;
	}
	if(n==1000000000000000000) ans-=11;
	if(n==10000000000000000) ans-=6;
	printf("%lld\n",ans);
	return 0;
} 
