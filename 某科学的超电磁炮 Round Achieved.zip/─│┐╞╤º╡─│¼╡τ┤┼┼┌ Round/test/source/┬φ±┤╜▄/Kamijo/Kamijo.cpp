#include<bits/stdc++.h>
using namespace std;
const int N=100005;
int n,q;
char s[100005];
int ans=0x3f3f3f3f;
int pra[N],prb[N],prc[N]; 
void dfs(int x,int cnt){
	int fl=0;
	/*for(int i=1;i<=n;i++){
		if(s[i]=='c'&&pra[prb[i]]>=1) fl=1;
	}*/
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(s[i]=='a'&&s[j]=='b'&&s[k]=='c') {
					fl=1;
					break;
				}
			}
			if(fl) break;
		}
		if(fl) break;
	}
	if(!fl){
		ans=min(ans,cnt);
		return ;
	}
	if(x+1>n) return ;
	char t=s[x+1];
	s[x+1]='a';
	dfs(x+1,cnt+(t!='a'));
	s[x+1]='b';
	dfs(x+1,cnt+(t!='b'));
	s[x+1]='c';
	dfs(x+1,cnt+(t!='c'));
	s[x+1]=t;
}
int main(){
	freopen("Kamijo.in","r",stdin);
	freopen("Kamijo.out","w",stdout);
	scanf("%d%d",&n,&q);
	cin>>s+1;
	for(int i=1;i<=q;i++){
		int x;
		char c;
		scanf("%d",&x);
		cin>>c;
		s[x]=c;
		ans=n;
	//	dfs(0,0); 
		dfs(0,0);
		printf("%d\n",ans);
		//mp[x]=ans;
	}
	return 0;
} 

