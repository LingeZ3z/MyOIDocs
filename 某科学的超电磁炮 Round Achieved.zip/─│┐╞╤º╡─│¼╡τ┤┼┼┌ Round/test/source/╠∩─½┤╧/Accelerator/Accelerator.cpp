#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
#include<unordered_map>
#include<cmath>
using namespace std;
#define ll long long
#define il inline
il ll read() {
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') {f=-1;} c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
ll n,ans,pri[18]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61};
ll root[18],l,r;
unordered_map<ll,bool> mp;
il ll qpow(ll a,ll b) {
	ll ans=1;
	while(b) {
		if(b&1) ans*=a;
		a*=a,b>>=1;
	}
	return ans;
}
il bool chk(ll x,ll y,ll n) {
	ll now=1;
	for(ll i=1;i<=y;i++) {
		if(now<=n/x) now*=x;
		else return 0;
	} 
	return 1;
}
int main() {
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	n=read();
	l=1,r=1e9,ans=1e9;
	while(l<=r) {
		ll mid=(l+r)>>1;
		if(mid*mid<=n) l=mid+1,ans=mid;
		else r=mid-1;
	}
	root[0]=ans;
	for(int i=1;i<18;i++) {
		ll a=pri[i];
		while(1) {
			if(chk(root[i]+1,a,n)) root[i]++;
			else break;
		}
	}
	//for(int i=0;i<18;i++) printf("%d\n",root[i]);
	for(ll i=1;i<18;i++) {
		ll a=pri[i],lim=root[i];
		if(lim<2) break;
		for(ll j=2;j<=lim;j++) {
			ll tmp=sqrtl(1.0*j),pp=qpow(j,a);
			if(tmp*tmp==j) continue;
			if(mp.count(pp)) continue;
			mp[pp]=1,ans++;
		}
	}
	printf("%lld\n",ans);
	return 0;
}

