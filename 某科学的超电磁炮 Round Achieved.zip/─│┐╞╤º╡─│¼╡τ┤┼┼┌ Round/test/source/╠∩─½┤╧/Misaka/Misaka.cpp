#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
using namespace std;
#define ll long long
#define il inline
il ll read() {
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') {f=-1;} c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
int n,m,r,ans;
int main() {
	freopen("Misaka.in","r",stdin);
	freopen("Misaka.out","w",stdout);
	n=read(),m=read(),r=read();
	for(int i=1;i<=n;i++) read(),read();
	for(int i=1;i<=m;i++) {
		read(),read();
		ans+=read();
	}
	printf("%d\n",ans);
	return 0;
}

