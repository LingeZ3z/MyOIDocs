#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
#include<deque>
using namespace std;
#define ll long long
#define il inline
#define N (1<<18)
il ll read() {
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') {f=-1;} c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
int n,m,q,a[N];
vector<int> bin[N];
int dis[N];
bool vis[N];
int que[N<<1];
vector<pair<int,int> > g[N<<1];
il void add_edge(int u,int v,int w) {
	g[u].push_back(make_pair(v,w));
}
il void bfs(int s) {
	deque<int> dq;
	memset(dis,0x3f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[s]=0;dq.push_back(s);
	while(!dq.empty()) {
		int u=dq.front();dq.pop_front();
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=0,v,w;i<g[u].size();i++) {
			v=g[u][i].first,w=g[u][i].second;
			if(vis[v]) continue;
			if(dis[v]>dis[u]+w) {
				dis[v]=dis[u]+w;
				if(w==1) dq.push_back(v);
				else dq.push_front(v);
			}
		}
	}
}
int main() {
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) {
		a[i]=read();
		if(a[i]==-1) a[i]=(1<<17)+i+1;
		bin[a[i]].push_back(i);
	}
	for(register int S=1;S<(1<<17);++S) {
		for(register int i=0;i<17;++i) {
			if(!(S&(1<<i))) continue;
			int T=S^(1<<i);
			if(T==S) continue;
			add_edge(S,T,0);
		}
	}
	for(register int i=1,u,v,bu,bv;i<=m;++i) {
		u=read(),v=read();
		bu=a[u],bv=a[v];
		if(bu==bv) continue;
		add_edge(bu,bv,1),add_edge(bv,bu,1);
	}
	while(q--) {
		int u=read(),v=read();
		bfs(a[u]);
		printf("%d\n",dis[a[v]]);
	}
	return 0;
}

