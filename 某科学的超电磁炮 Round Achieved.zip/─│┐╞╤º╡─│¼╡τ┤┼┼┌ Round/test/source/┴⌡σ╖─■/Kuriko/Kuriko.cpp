#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
#define fo(a,i,b) for(register ll i = a ; i <= b ; ++ i )
#define Fo(a,i,b) for(register ll i = a ; i >= b ; -- i )
//#pragma GCC optimize(2)
using namespace std;
typedef int ll;
const int N=6e5+5,M=9e6+5;
inline void read(ll &opp){ll x=0,t=1;char ch;ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-'){t=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}opp=x*t;return; }
inline void wr(ll x){if(x<0){putchar('-');x=-x;}if(x>9){wr(x/10);}putchar(x%10+'0');}
ll n,m,head[N],tot,q,a[N],maxn,pw[20],dis[N],vis[N];
struct Graph{ll ver,nxt,w;}g[M];
inline void add(ll x,ll y,ll z){g[++tot].ver=y,g[tot].nxt=head[x];head[x]=tot;g[tot].w=z;}
deque<ll> pq;
inline void dij(ll x){
	pq.push_front(x);fo(0,i,pw[17]+n+1) dis[i]=INF,vis[i]=0;dis[x]=0;
	while(!pq.empty()){
		ll y=pq.front();pq.pop_front();
		if(vis[y]) continue;vis[y]=1;
		for(int i=head[y];i;i=g[i].nxt){
			ll v=g[i].ver;if(vis[v]) continue;
			if(dis[v]>dis[y]+g[i].w){
				dis[v]=dis[y]+g[i].w;
				if(g[i].w) pq.push_back(v);
				else pq.push_front(v);
			}
		}
	}
}
signed main(){
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
	read(n),read(m),read(q);ll L=n+1;
	fo(1,i,n) read(a[i]);fo(0,i,17) pw[i]=1<<i;
	fo(1,i,m){ll u,v;read(u),read(v);add(u,v,1),add(v,u,1);}
	fo(0,i,pw[17]) fo(0,j,16) if(i&pw[j]) add(i+L,(i^pw[j])+L,0);
	fo(1,i,n){
		if(a[i]==-1) continue;
		add(i,a[i]+L,0);
		add(a[i]+L,i,0);
	}
	fo(1,i,q){
		ll u,v;read(u),read(v);
		dij(u);wr(dis[v]);putchar('\n');
	}
	return 0;
}

