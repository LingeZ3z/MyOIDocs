#include<bits/stdc++.h>
#define INF 0x3f3f3f3f3f3f3f3f
#define pr printf("\n")
#define pp printf(" ")
#define pii pair<ll,ll>
#define mem(aa,bb) memset(aa,bb,sizeof(aa))
#define fo(a,i,b) for(ll i = a ; i <= b ; ++ i )
#define Fo(a,i,b) for(ll i = a ; i >= b ; -- i )
#define bug (x>=1&&x<=n&&y>=1&&y<=m) 
using namespace std;
typedef long long ll;
const int N=3e5+5,M=5e6+5;
inline void read(ll &opp){ll x=0,t=1;char ch;ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-'){t=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}opp=x*t;return; }
inline void wr(ll x){if(x<0){putchar('-');x=-x;}if(x>9){wr(x/10);}putchar(x%10+'0');}

ll n,m,r,vis[N],maxn,minx=INF;
struct Point{
	ll x,y;
}a[N];
struct Using{
	ll x,y,c;
}b[N];
inline ll dist(ll x1,ll y1,ll x2,ll y2){return ceil(sqrt(1.0*(x1-x2)*(x1-x2)+1.0*(y1-y2)*(y1-y2)));}
inline void check(ll x,ll csum,ll rsum){
	if(x>m){
		if(rsum>maxn) maxn=rsum,minx=csum;
		else if(rsum==maxn&&csum<minx) minx=csum;
		return;
	}
	check(x+1,csum,rsum);
	queue<ll> q;ll cnt=0;
	fo(1,i,n) if(dist(a[i].x,a[i].y,b[x].x,b[x].y)<=r&&!vis[i]) vis[i]=1,cnt++,q.push(i);
	check(x+1,csum+b[x].c,rsum+cnt);
	while(!q.empty()) vis[q.front()]=0,q.pop();
}
signed main(){
	freopen("Misaka.in","r",stdin);
	freopen("Misaka.out","w",stdout);
	read(n),read(m),read(r);
	fo(1,i,n) read(a[i].x),read(a[i].y);
	fo(1,i,m) read(b[i].x),read(b[i].y),read(b[i].c);
	check(1,0,0);
	wr(minx);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
5 5 1
9 14 9 4 3
1 2
1 3
1 5
2 5
3 4
5 2
*/
