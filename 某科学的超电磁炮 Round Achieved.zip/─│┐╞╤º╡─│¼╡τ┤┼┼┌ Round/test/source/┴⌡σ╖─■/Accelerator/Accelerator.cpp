#include<bits/stdc++.h>
#define INF 0x3f3f3f3f3f3f3f3f
#define pr printf("\n")
#define pp printf(" ")
#define pii pair<ll,ll>
#define mem(aa,bb) memset(aa,bb,sizeof(aa))
#define fo(a,i,b) for(ll i = a ; i <= b ; ++ i )
#define Fo(a,i,b) for(ll i = a ; i >= b ; -- i )
#define bug (x>=1&&x<=n&&y>=1&&y<=m) 
using namespace std;
typedef __int128 ll;
typedef __int128 i128;
typedef double db;
const int N=1e6+5,M=1e7+5;
const db eps=1e-7;
inline void read(ll &opp){ll x=0,t=1;char ch;ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-'){t=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}opp=x*t;return; }
inline void wr(ll x){if(x<0){putchar('-');x=-x;}if(x>9){wr(x/10);}putchar(x%10+'0');}
ll x,sum,cnt;
map<ll,ll> mp;
inline void check(ll x){
	for(ll i=2;i*i*i<=x;i++){
		ll op=i*i;
		while(op<=x/i){
			op*=i;if(mp[op]) continue;
			if(ll(sqrtl(op))*ll(sqrtl(op))==op) sum--,cnt++;mp[op]=1,sum++;
		}
	}
}
signed main(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	read(x);check(x);
	wr(ll(sqrtl(x))+sum),pr;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
