#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
#define pr printf("\n")
#define pp printf(" ")
#define pii pair<ll,ll>
#define mem(aa,bb) memset(aa,bb,sizeof(aa))
#define fo(a,i,b) for(ll i = a ; i <= b ; ++ i )
#define Fo(a,i,b) for(ll i = a ; i >= b ; -- i )
#define bug (x>=1&&x<=n&&y>=1&&y<=m) 
using namespace std;
typedef int ll;
const int N=3e5+5,M=5e6+5;
inline void read(ll &opp){ll x=0,t=1;char ch;ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-'){t=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}opp=x*t;return; }
inline void wr(ll x){if(x<0){putchar('-');x=-x;}if(x>9){wr(x/10);}putchar(x%10+'0');}

ll n,q,preA[N],preB[N],preC[N];
string s;
inline ll check(){
	preA[0]=preC[n+1]=0;ll ans=0;
	fo(1,i,n) preA[i]=preA[i-1]+(s[i]=='a'?1:0);
	Fo(n,i,1) preC[i]=preC[i+1]+(s[i]=='c'?1:0);
	ll sumB=0,sumA=0,sumC=0,lasA=0,lasC=0;
	fo(1,i,n){
		if(s[i]=='b'&&preA[i]&&preC[i]) sumB++;
		if(s[i]=='b'&&preA[i]-lasA&&preC[i]) sumA+=preA[i]-lasA,lasA=preA[i];  
	}
	Fo(n,i,1){
		if(s[i]=='b'&&preA[i]&&preC[i]-lasC) sumC+=preC[i]-lasC,lasC=preC[i];
	}
	return min(sumB,min(sumA,sumC));
}
signed main(){
	freopen("Kamijo.in","r",stdin);
	freopen("Kamijo.out","w",stdout);
	read(n),read(q);
	cin>>s;s=" "+s;
	fo(1,i,q){
		ll pos;char c;
		read(pos);cin>>c;
		s[pos]=c;
		if(n*q<=1e8) wr(check()),pr;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
5 5 1
9 14 9 4 3
1 2
1 3
1 5
2 5
3 4
5 2
*/
