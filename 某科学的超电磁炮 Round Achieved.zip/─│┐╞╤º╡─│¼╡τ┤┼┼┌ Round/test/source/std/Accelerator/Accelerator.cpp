#include <bits/stdc++.h>
using namespace std;
#define int long long
int solve1(int n){
	int ans=0;
	map<int,bool> mp;
	for(int i=2;i*i*i<=n;i++){
		int i3=i*i;
		while(i3<=n/i){
			i3*=i;
			if(!mp[i3]){
				mp[i3]=1;
				if(((int)sqrtl(i3)*(int)sqrtl(i3))!=i3)ans++;
			}
		}
	}
	ans+=sqrtl(n);
	return ans;
}
signed main(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int n;cin>>n;
	cout<<solve1(n)<<endl;
	return 0;
}
