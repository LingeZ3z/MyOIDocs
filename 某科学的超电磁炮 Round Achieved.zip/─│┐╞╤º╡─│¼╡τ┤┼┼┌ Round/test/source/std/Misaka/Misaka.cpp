#include <bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> pii;
#define fi first
#define se second
#define mp make_pair
#define pb push_back
const int N=110,INF=1145141919810;
int n,m,r;
pii p[N],a[N];
int x[N],y[N],c[N];
int f[N][N][N];
bool can[N];
int dis2(pii *p,int i,int j){
	return (p[i].fi-x[j])*(p[i].fi-x[j])+
		(p[i].se-y[j])*(p[i].se-y[j]);
}
signed main(){
	freopen("Misaka.in","r",stdin);
	freopen("Misaka.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m>>r;
	for(int i=1;i<=n;i++)cin>>p[i].fi>>p[i].se;
	for(int i=1;i<=m;i++)cin>>x[i]>>y[i]>>c[i];
	sort(p+1,p+1+n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(dis2(p,i,j)<=r*r)
				can[i]=1;
	int cnt=0;
	for(int i=1;i<=n;i++)
		if(can[i])a[++cnt]=p[i];
	sort(a+1,a+1+cnt);
	memset(f,0x3f,sizeof(f));
	f[0][0][0]=0;
	for(int i=1;i<=cnt;i++)
		for(int j=0;j<=m;j++)
			for(int k=0;k<=m;k++)
				for(int l=1;l<=m;l++){
					if(dis2(a,i,l)>r*r)continue;
					if(y[l]>r)f[i][l][k]=min(f[i][l][k],f[i-1][j][k]+(l==j?0:c[l]));
					else f[i][j][l]=min(f[i][j][l],f[i-1][j][k]+(l==k?0:c[l]));
				}
	int ans=INF;
	for(int i=0;i<=m;i++)
		for(int j=0;j<=m;j++)
			ans=min(ans,f[cnt][i][j]);
	cout<<ans<<'\n';
	return 0;
}
