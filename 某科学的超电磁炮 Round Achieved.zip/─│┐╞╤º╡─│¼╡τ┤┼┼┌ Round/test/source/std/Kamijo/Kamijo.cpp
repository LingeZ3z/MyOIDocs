#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+10,INF=0x3f3f3f3f3f3f3f3f,mod=1e9+7;
int n,q;
char s[N];
struct node{
	int a,b,c;
	int ab,bc,abc;
}t[N*4];
void pushup(int p){
	t[p].a=t[p*2].a+t[p*2+1].a;
	t[p].b=t[p*2].b+t[p*2+1].b;
	t[p].c=t[p*2].c+t[p*2+1].c;
	t[p].ab=min(t[p*2].ab+t[p*2+1].b,t[p*2].a+t[p*2+1].ab);
	t[p].bc=min(t[p*2].bc+t[p*2+1].c,t[p*2].b+t[p*2+1].bc);
	t[p].abc=min({t[p*2].abc+t[p*2+1].c,t[p*2].ab+t[p*2+1].bc,t[p*2].a+t[p*2+1].abc});
}
void build(int p,int l,int r){
	if(l==r){
		if(s[l]=='a')t[p].a=1;
		if(s[l]=='b')t[p].b=1;
		if(s[l]=='c')t[p].c=1;
		return;
	}
	int m=(l+r)>>1;
	build(p*2,l,m);
	build(p*2+1,m+1,r);
	pushup(p);
}
void update(int p,int l,int r,int pos,char c){
	if(l==r){
		t[p].a=t[p].b=t[p].c=0;
		if(c=='a')t[p].a=1;
		if(c=='b')t[p].b=1;
		if(c=='c')t[p].c=1;
		return;
	}
	int m=(l+r)>>1;
	if(pos<=m)update(p*2,l,m,pos,c);
	else update(p*2+1,m+1,r,pos,c);
	pushup(p);
}
signed main(){
	freopen("Kamijo.in","r",stdin);
	freopen("Kamijo.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n>>q;
	cin>>(s+1);
	build(1,1,n);
	for(int i=1;i<=q;i++){
		int p;char c;
		cin>>p>>c;
		update(1,1,n,p,c);
		cout<<t[1].abc<<'\n';
	}
	return 0;
}
