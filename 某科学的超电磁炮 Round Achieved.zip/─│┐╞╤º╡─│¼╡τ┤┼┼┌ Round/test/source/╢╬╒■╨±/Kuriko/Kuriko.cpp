#include <cstring>
#include <deque>
#include <iostream>
#include <tuple>
#include <vector>
using namespace std;
const int N = 3e5 + 5, INF = 0x3f3f3f3f;
int n, m, q, a[N], dis[N];
bool vis[N];
vector<pair<int, int>> G[N];
deque<int> Q;
void add(int u, int v, int w) { G[u].emplace_back(v, w); }
void addedge(int u, int v, int w) { add(u, v, w), add(v, u, w); }
int bfs(int s, int t) {
    memset(dis, 0x3f, sizeof(dis));
    memset(vis, false, sizeof(vis));
    Q.clear(), Q.push_back(s), dis[s] = 0;
    while (Q.size()) {
        int u = Q.front();
        Q.pop_front();
        if (u == t) break;
        if (vis[u]) continue;
        vis[u] = true;
        for (auto p : G[u]) {
            int v, w;
            tie(v, w) = p;
            if (dis[v] > dis[u] + w) {
                if (w) Q.push_back(v);
                else Q.push_front(v);
                dis[v] = dis[u] + w;
            }
        }
    }
    return dis[t];
}
int main() {
    freopen("Kuriko.in", "r", stdin);
    freopen("Kuriko.out", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> m >> q;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1, u, v; i <= m; i++) cin >> u >> v, addedge(u, v, 1);
    for (int i = 0; i < (1 << 17); i++)
        for (int j = 0; j < 17; j++)
            if (i & (1 << j)) add(i + n + 1, (i ^ (1 << j)) + n + 1, 0);
    for (int i = 1; i <= n; i++)
        if (a[i] != -1) addedge(i, a[i] + n + 1, 0);
    for (int i = 1, u, v; i <= q; i++) cin >> u >> v, cout << bfs(u, v) << '\n';
}