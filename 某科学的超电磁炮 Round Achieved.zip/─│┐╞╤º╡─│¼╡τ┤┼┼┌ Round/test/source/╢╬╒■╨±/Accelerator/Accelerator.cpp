#include <cmath>
#include <iostream>
#include <set>
#include <stdfloat>
using namespace std;
using i64 = long long;
using i128 = __int128;
i64 n, ans;
set<i128> S;
i128 qpow(i128 x, int y) {
    i128 ret = 1;
    for (; y; y >>= 1, x = x * x)
        if (y & 1) ret = ret * x;
    return ret;
}
bool sqrtable(i128 x) { return qpow(sqrt((long double)x), 2) == x; }
int main() {
    freopen("Accelerator.in", "r", stdin);
    freopen("Accelerator.out", "w", stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n;
    ans = sqrt(n);
    for (int i = 2; i <= cbrt(n); i++)
        for (int j = 3; j <= 100; j++) {
            i128 k = qpow(i, j);
            if (k <= n) {
                if (S.find(k) == S.end() && !sqrtable(k)) ++ans, S.insert(k);
            } else break;
        }
    cout << ans;
}