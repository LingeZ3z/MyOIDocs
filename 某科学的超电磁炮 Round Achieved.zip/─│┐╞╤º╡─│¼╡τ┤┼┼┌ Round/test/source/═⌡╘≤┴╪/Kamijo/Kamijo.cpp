#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char s[100005],ss[100005];int n,q;
int A[5005],AB[5005],BC[5005],C[5005];
int mn=1000000000;
void dfs(int x){
	if(x==n+1){
		bool a[15],ab[15],abc=0;
		a[0]=ab[0]=0;
		for(int i=1; i<=n; i++){
			a[i]=a[i-1]|(ss[i]=='a');
			ab[i]=ab[i-1]|(a[i]&(ss[i]=='b'));
			abc|=(ss[i]=='c'&&ab[i]);
		}if(abc)return;
		int cnt=n;
		for(int i=1;i <=n;i ++)cnt-=(s[i]==ss[i]);
		mn=min(mn,cnt);
		return;
	}ss[x]='a';
	dfs(x+1);
	ss[x]='b';
	dfs(x+1);
	ss[x]='c';
	dfs(x+1);
}
int main(){
	freopen("Kamijo.in","r",stdin);
	freopen("Kamijo.out","w",stdout);
	scanf("%d%d",&n,&q);
	scanf("%s",s+1);
	if(n<=10){
		while(q--){
			int p;
			char ss[10];
			scanf("%d%s",&p,ss);
			s[p]=ss[0];
			mn=1000000000;
			dfs(1);
			printf("%d\n",mn);
		}
	}
	else if(n<=5000){
		while(q--){
			int pos;
			char ss[10];
			scanf("%d %s",&pos,ss);
			s[pos]=ss[0];
			for(int i=1; i<=n; i++){
				A[i]=A[i-1]+(s[i]=='a');
				AB[i]=AB[i-1]+(s[i]=='b'&&A[i]);
			}for(int i=n; i>=1; i--){
				C[i]=C[i+1]+(s[i]=='c');
				BC[i]=BC[i+1]+(s[i]=='b'&&C[i]);
			}
			int a=0,b=0,c=0;
			for(int i=1; i<=n; i++){
				a+=(s[i]=='a'&&BC[i]);
				b+=(s[i]=='b'&&A[i]&&C[i]);
				c+=(s[i]=='c'&&AB[i]);
			}printf("%d\n",min(a,min(b,c)));
		}
	}
	return 0;
}/*
9 12
aaabccccc
4 a
4 b
2 b
5 a
1 b
6 b
5 c
2 a
1 a
5 a
6 b
7 b

*/
