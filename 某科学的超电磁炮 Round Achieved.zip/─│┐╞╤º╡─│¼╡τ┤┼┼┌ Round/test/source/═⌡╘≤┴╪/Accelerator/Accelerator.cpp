#include<bits/stdc++.h>
#include<unordered_map>
using namespace std;
int pri[20]={-1,2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61};
unordered_map<long long,bool>mp;
int curt(long long tmp){
	for(int i=1; i<=1000001; i++){
		if(i*1ll*i*1ll*i>tmp)return i-1;
	}
}
int main(){
	freopen("Accelerator.in","r",stdin);
	freopen("Accelerator.out","w",stdout);
	long long n;
	scanf("%lld",&n);
	int tmp=curt(n);
	long long cnt=0;
	bool op=1;
	for(int i=2; i<=tmp; i++){
		int ii=(int)sqrtl(i);
		if(ii*ii==i){continue;}
		__int128 t=i;
		int now=1;
		for(int j=2; j<=17; j++){
			while(now<pri[j]&&t<=n)t=t*1ll*i,now++;
			if(now!=pri[j]||n<t)break;
			cnt+=(!mp[t]);
			mp[t]=1;
		}
	}
	printf("%lld\n",(long long)sqrtl(n)+cnt);
	return 0;
} //1000000000
