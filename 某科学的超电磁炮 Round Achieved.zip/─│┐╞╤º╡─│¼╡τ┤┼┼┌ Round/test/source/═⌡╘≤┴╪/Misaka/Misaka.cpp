#include<iostream>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<cstdio>
using namespace std;
int ans[105];
struct node{
	int x,y,c;
}a[105],b[105];
int n,m,r;
bool chk(node a,node b){
	long long t1=(a.x-b.x),t2=(a.y-b.y);
	return t1*t1+t2*t2<=r*1ll*r;
}int can[105];
int lowbit(int x){return x&-x;}
int popcnt(int x){
	int ans=0;
	while(x)ans++,x-=lowbit(x);
	return ans;
}int doit(int S){
	int cost=0,ca=0;
	for(int i=1; i<=m; i++){
		if((S>>(i-1))&1){
			cost+=b[i].c,ca|=can[i];
		}
	}int t=popcnt(ca);
	ans[t]=min(ans[t],cost);
	return t;
}
int main(){
	freopen("Misaka.in","r",stdin);
	freopen("Misaka.out","w",stdout);
//	memset(ans,0x3f,sizeof ans);
	for(int i=1; i<=100; i++)ans[i]=1000000000;
	scanf("%d%d%d",&n,&m,&r);
	for(int i=0; i<n; i++){
		scanf("%d%d",&a[i].x,&a[i].y);
	}for(int i=1; i<=m; i++){
		scanf("%d%d%d",&b[i].x,&b[i].y,&b[i].c);
	}
	for(int i=1; i<=m; i++){
		for(int j=0; j<n ;j++){
			can[i]|=(chk(a[j],b[i])<<j); 
		}
	}if(n<=20){
		int mx=0;
		for(int S=0; S<(1<<m); S++){
			int cost=0,ca=0;
			for(int i=1; i<=m; i++){
				if((S>>(i-1))&1){
					cost+=b[i].c,ca|=can[i];
				}
			}ans[popcnt(ca)]=min(ans[popcnt(ca)],cost);
			mx=max(mx,popcnt(ca));
		}printf("%d\n",ans[mx]);
	}else{
		srand(41); 
		int cost=0,S=rand()%(1<<m),mx=0;
		int T=5000000;
		while(T--){
			int t=rand()%m;
			S^=(1<<t);
//			S=rand()%(1<<m);
			mx=max(mx,doit(S));
		}cout<<ans[mx];
	}
	
	
	return 0;
}
