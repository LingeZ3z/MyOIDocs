# 题意

给定一个 $n$ 个点，$m$ 条边的无向联通图，每条边权值为 $1$。对于每个点 $u$ 给定权值 $a_u$。若 $a_u \operatorname{and} a_v=a_v $（其中 $\operatorname{and}$ 表示位运算中的与），则在原图中添加一条从 $u$ 到 $v$ 的**单向**边，**其权值为** $0$。

现在有 $q$ 次询问，每次询问给定 $u,v$，问图中 $u$ 到 $v$ 的最短路径长度为多少。

# 输入格式

第一行三个正整数 $n,m,q$，与题目描述相同。

第二行 $n$ 个整数，第 $i$ 个数表示 $a_i$。

接下来 $m$ 行每行两个正整数 $u,v(1\leq u,v\leq n)$，表示原图中一条边。

接下来 $q$ 行每行两个正整数 $u,v(1\leq u,v\leq n)$，表示一次询问。

# 输出格式

每次询问输出一个整数，代表这次询问的答案。

# 数据范围及部分分：

本题使用 Subtask。

- Subtask 0 $(10\operatorname{pts})$：$n\leq 10^3,m\leq 3\times 10^3,q\leq 100$。
- Subtask 1 $(20\operatorname{pts})$：$n\leq 10^5,m=n-1,q\leq 100$。
- Subtask 2 $(20\operatorname{pts})$：$n\leq 10^5,m\leq 3\times 10^5,q=1,a_u\in[0,2^{11})$。
- Subtask 3 $(50\operatorname{pts})$：无特殊限制。

对于所有数据，满足 $n\leq 10^5,m\leq 3\times 10^5,q\leq 100,a_u\in[0,2^{17})$，**最终图中的边数** $\leq 5\times 10^6$（双向边算作一条边）。

保证最初给定的图联通。