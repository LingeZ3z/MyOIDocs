#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<vector>
using namespace std;
vector<int>G[300005];
int a[300005];
vector<int>val[200005];
deque<int>q;
int tmp,stp[300005];
bool get[300005];
int bfs(){
	int ans=1000000000;
	while(!q.empty()){
		int x=q.front();
		q.pop_front();
		if(((a[x]&tmp)==tmp)){
			ans=stp[x];
			break;
		}
		for(int i=0; i<G[x].size(); i++){
			int y=G[x][i];
			if(stp[y]==-1){
				stp[y]=stp[x]+1;
				q.push_back(y);
			}
		}
		int cnt=0;
		if(a[x]!=-1&&!get[x]){
//		cerr<<"!!!"<<endl;
			for(int S=a[x]; S; S=((S-1)&a[x])){
				if(val[S].size()){
					for(int j=0; j<val[S].size(); j++){
						cnt++;
						int y=val[S][j];
						if(stp[y]==-1){
							stp[y]=stp[x];
							q.push_front(y);
							get[y]=1;
						}
					}
				}
			}
		}
//		cerr<<x<<' '<<cnt<<endl;
		
	}
	while(!q.empty())q.pop_front();
	return ans;
}
int main(){
	freopen("Kuriko.in","r",stdin);
	freopen("Kuriko.out","w",stdout);
	int n,m,qq;
	scanf("%d%d%d",&n,&m,&qq);
	for(int i=1; i<=n; i++){
		scanf("%d",&a[i]);
		if(a[i]!=-1)val[a[i]].push_back(i);
	}
	for(int i=1; i<=m; i++){
		int x,y;
		scanf("%d%d",&x,&y);
		G[x].push_back(y);
		G[y].push_back(x);
	}while(qq--){
		int u,v;
		scanf("%d%d",&u,&v);
		if(a[u]!=-1&&a[v]!=-1&&((a[u]&a[v])==a[v])){
			printf("0\n");
			continue;
		}memset(stp,-1,sizeof stp);
		tmp=a[v];
		q.push_back(u);
		memset(get,0,sizeof get);
		stp[u]=0;
		printf("%d\n",bfs());
	}
	return 0;
}
