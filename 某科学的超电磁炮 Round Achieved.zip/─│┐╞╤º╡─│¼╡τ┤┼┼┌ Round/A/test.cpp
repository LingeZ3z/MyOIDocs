#include <bits/stdc++.h>
using namespace std;

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int a=131071,cnt=0;
	for(int S=a; S; S=((S-1)&a)){
		cnt++;
	}
	cout<<cnt<<endl;
	return 0;
}
