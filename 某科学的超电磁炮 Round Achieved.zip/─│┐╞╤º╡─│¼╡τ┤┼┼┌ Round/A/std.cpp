#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10,M=5e6+10,V=(1<<17)+10;
int n,m,q;
struct edge{
	int v,w,nxt;
}e[M];
int head[N+V],cnt=2;
void add(int u,int v,int w){
	e[cnt].v=v;
	e[cnt].w=w;
	e[cnt].nxt=head[u];
	head[u]=cnt++;
}
int a[N];
bool vis[N+V];
int dis[N+V];
int bfs(int s,int t){
	memset(dis,0x3f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	deque<int> q;
	q.push_front(s);
	dis[s]=0;
	while(q.size()){
		int u=q.front();q.pop_front();
		if(u==t)return dis[u];
		if(vis[u])continue;
		vis[u]=1;
		for(int i=head[u];i;i=e[i].nxt){
			if(vis[e[i].v])continue;
			if(dis[e[i].v]>dis[u]+e[i].w){
				dis[e[i].v]=dis[u]+e[i].w;
				if(e[i].w)q.push_back(e[i].v);
				else q.push_front(e[i].v);
			}
		}
	}
	return 26262626;
}
int mx=0;
signed main(){
//	freopen("a.in","r",stdin);
//	freopen("a.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i],mx=max(mx,a[i]);
	for(int i=1;i<=m;i++){
		int u,v;cin>>u>>v;
		add(u,v,1),add(v,u,1);
	}
	for(int u=1;u<=n;u++){
		if(a[u]==-1)continue;
		add(u,n+1+a[u],0);
		add(n+1+a[u],u,0);
	}
	for(int i=0;i<=mx;i++){
		for(int j=1;j<(1<<17);j<<=1){
			if(i&j)continue;
			add(n+1+(i|j),n+1+i,0);
		}
	}
	for(int i=1;i<=q;i++){
		int u=0,v=0;
		cin>>u>>v;
		cout<<bfs(u,v)<<'\n';
	}
	return 0;
}
