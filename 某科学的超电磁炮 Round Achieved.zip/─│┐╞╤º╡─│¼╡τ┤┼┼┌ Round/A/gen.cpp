#include <bits/stdc++.h>
#include "./../testlib.h"
using namespace std;
#define int long long
typedef long long ll;
typedef pair<int,int> pii;
#define fi first
#define se second
#define mp make_pair
pii npm(int x,int y){if(x>y)swap(x,y);return mp(x,y);}
#define pb push_back
const ll INFL=0x3f3f3f3f3f3f3f3f,mod=1e9+7;
const int N=1e5+10,M=3e5+10,Q=110;
int fa[N],a[N],u[Q],v[Q];
map<pii,int> edge;
struct ed{
	int v,nxt;
}e[N*2];
int head[N],cnt=2;
void add(int u,int v){
	e[cnt].v=v;
	e[cnt].nxt=head[u];
	head[u]=cnt++;
}
bool vis[N];
void dfs(int u){
	vis[u]=1;
	for(int i=head[u];i;i=e[i].nxt){
		if(!vis[e[i].v])dfs(e[i].v);
	}
}
signed main(signed argc,char *argv[]){
	registerGen(argc,argv,1);
	int n=opt<int>("n");
	int m=opt<int>("m");
	int q=opt<int>("q");
	int mxa=opt<int>("mxa");
	for(int i=1;i<=n;i++)a[i]=rnd.next(mxa);
	for(int i=2;i<=n;i++){
		fa[i]=rnd.next(1ll,i-1);
		edge[npm(i,fa[i])]=1;
		add(i,fa[i]);
		add(fa[i],i);
	}
	for(int i=1;i<=m-n+1;i++){
		St:;
		int u=rnd.next(1ll,n);
		int v=rnd.next(1ll,n);
		pii p=npm(u,v);
		if(edge[p])goto St;
		edge[p]=1;
	}
	for(int i=1;i<=q;i++){
		u[i]=rnd.next(1ll,n);
		v[i]=rnd.next(1ll,n);
	}
	printf("%d %d %d\n",n,m,q);
	for(int i=1;i<=n;i++)printf("%d ",a[i]);
	printf("\n");
	for(pair<pii,bool> p:edge)printf("%d %d\n",p.fi.fi,p.fi.se);
	for(int i=1;i<=q;i++)printf("%d %d\n",u[i],v[i]);
	return 0;
}
