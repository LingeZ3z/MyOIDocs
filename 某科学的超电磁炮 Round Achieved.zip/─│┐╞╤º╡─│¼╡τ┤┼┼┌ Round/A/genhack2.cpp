#include <bits/stdc++.h>
#include "./../testlib.h"
using namespace std;
#define int long long
typedef long long ll;
typedef pair<int,int> pii;
#define fi first
#define se second
#define mp make_pair
pii npm(int x,int y){if(x>y)swap(x,y);return mp(x,y);}
#define pb push_back
const ll INFL=0x3f3f3f3f3f3f3f3f,mod=1e9+7;
const int N=1e5+10,M=3e5+10,Q=110;
int fa[N],a[N],u[Q],v[Q];
map<pii,int> edge;
struct ed{
	int v,nxt;
}e[N*2];
int head[N],cnt=2;
void add(int u,int v){
	e[cnt].v=v;
	e[cnt].nxt=head[u];
	head[u]=cnt++;
}
bool vis[N];
void dfs(int u){
	vis[u]=1;
	for(int i=head[u];i;i=e[i].nxt){
		if(!vis[e[i].v])dfs(e[i].v);
	}
}
signed main(signed argc,char *argv[]){
	registerGen(argc,argv,1);
	int n=opt<int>("n");
	int q=opt<int>("q");
	int m=n-1;
	for(int i=1;i<=n;i++){
		if(i!=n)a[i]=(1<<17)-n+i;
		else a[i]=-1;
	}
	for(int i=2;i<=n;i++){
		fa[i]=i-1;
		edge[mp(fa[i],i)]=1;
	}
	for(int i=1;i<=q;i++)u[i]=1,v[i]=n;
	cout<<n<<' '<<m<<' '<<q<<'\n';
	for(int i=1;i<=n;i++)cout<<a[i]<<' ';
	cout<<'\n';
	for(pair<pii,bool> p:edge)cout<<p.fi.fi<<' '<<p.fi.se<<'\n';
	for(int i=1;i<=q;i++)cout<<u[i]<<' '<<v[i]<<'\n';
	return 0;
}
