#include "./../testlib.h"
#include <bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> pii;
#define fi first
#define se second
#define mp make_pair
#define pb push_back
const int N=110,INF=1145141919810;

signed main(signed argc,char *argv[]){
	registerGen(argc,argv,1);
	int n,m,r;
	cin>>n>>m>>r;
	cout<<n<<' '<<m<<' '<<r<<'\n';
	for(int i=1;i<=n;i++){
		int x,y;cin>>x>>y;
		cout<<x<<' '<<y<<'\n';
	}
	for(int i=1;i<=m;i++){
		int x,y,c;cin>>x>>y>>c;
		cout<<x<<' '<<y<<' '<<rnd.next(0,10000)<<'\n';
	}
	return 0;
}
